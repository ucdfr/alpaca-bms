/*******************************************************************************
* File Name: DEBUG_UART_audio.h
* Version 2.80
*
* Description:
*  Header File for the USBFS component. Contains prototypes and constant values.
*
* Related Document:
*  Universal Serial Bus Device Class Definition for Audio Devices Release 1.0
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_USBFS_DEBUG_UART_audio_H)
#define CY_USBFS_DEBUG_UART_audio_H

#include "cytypes.h"


/***************************************
* Custom Declarations
***************************************/

/* `#START CUSTOM_CONSTANTS` Place your declaration here */

/* `#END` */


/***************************************
*  Constants for DEBUG_UART_audio API.
***************************************/

/* Audio Class-Specific Request Codes (AUDIO Table A-9) */
#define DEBUG_UART_REQUEST_CODE_UNDEFINED     (0x00u)
#define DEBUG_UART_SET_CUR                    (0x01u)
#define DEBUG_UART_GET_CUR                    (0x81u)
#define DEBUG_UART_SET_MIN                    (0x02u)
#define DEBUG_UART_GET_MIN                    (0x82u)
#define DEBUG_UART_SET_MAX                    (0x03u)
#define DEBUG_UART_GET_MAX                    (0x83u)
#define DEBUG_UART_SET_RES                    (0x04u)
#define DEBUG_UART_GET_RES                    (0x84u)
#define DEBUG_UART_SET_MEM                    (0x05u)
#define DEBUG_UART_GET_MEM                    (0x85u)
#define DEBUG_UART_GET_STAT                   (0xFFu)

/* point Control Selectors (AUDIO Table A-19) */
#define DEBUG_UART_EP_CONTROL_UNDEFINED       (0x00u)
#define DEBUG_UART_SAMPLING_FREQ_CONTROL      (0x01u)
#define DEBUG_UART_PITCH_CONTROL              (0x02u)

/* Feature Unit Control Selectors (AUDIO Table A-11) */
#define DEBUG_UART_FU_CONTROL_UNDEFINED       (0x00u)
#define DEBUG_UART_MUTE_CONTROL               (0x01u)
#define DEBUG_UART_VOLUME_CONTROL             (0x02u)
#define DEBUG_UART_BASS_CONTROL               (0x03u)
#define DEBUG_UART_MID_CONTROL                (0x04u)
#define DEBUG_UART_TREBLE_CONTROL             (0x05u)
#define DEBUG_UART_GRAPHIC_EQUALIZER_CONTROL  (0x06u)
#define DEBUG_UART_AUTOMATIC_GAIN_CONTROL     (0x07u)
#define DEBUG_UART_DELAY_CONTROL              (0x08u)
#define DEBUG_UART_BASS_BOOST_CONTROL         (0x09u)
#define DEBUG_UART_LOUDNESS_CONTROL           (0x0Au)

#define DEBUG_UART_SAMPLE_FREQ_LEN            (3u)
#define DEBUG_UART_VOLUME_LEN                 (2u)

#if !defined(USER_SUPPLIED_DEFAULT_VOLUME_VALUE)
    #define DEBUG_UART_VOL_MIN_MSB            (0x80u)
    #define DEBUG_UART_VOL_MIN_LSB            (0x01u)
    #define DEBUG_UART_VOL_MAX_MSB            (0x7Fu)
    #define DEBUG_UART_VOL_MAX_LSB            (0xFFu)
    #define DEBUG_UART_VOL_RES_MSB            (0x00u)
    #define DEBUG_UART_VOL_RES_LSB            (0x01u)
#endif /* USER_SUPPLIED_DEFAULT_VOLUME_VALUE */


/***************************************
* External data references
***************************************/

extern volatile uint8 DEBUG_UART_currentSampleFrequency[DEBUG_UART_MAX_EP]
                                                             [DEBUG_UART_SAMPLE_FREQ_LEN];
extern volatile uint8 DEBUG_UART_frequencyChanged;
extern volatile uint8 DEBUG_UART_currentMute;
extern volatile uint8 DEBUG_UART_currentVolume[DEBUG_UART_VOLUME_LEN];
extern volatile uint8 DEBUG_UART_minimumVolume[DEBUG_UART_VOLUME_LEN];
extern volatile uint8 DEBUG_UART_maximumVolume[DEBUG_UART_VOLUME_LEN];
extern volatile uint8 DEBUG_UART_resolutionVolume[DEBUG_UART_VOLUME_LEN];

#endif /*  CY_USBFS_DEBUG_UART_audio_H */


/* [] END OF FILE */
