/*******************************************************************************
* File Name: DEBUG_UART_audio.c
* Version 2.80
*
* Description:
*  USB AUDIO Class request handler.
*
* Related Document:
*  Universal Serial Bus Device Class Definition for Audio Devices Release 1.0
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DEBUG_UART.h"

#if defined(DEBUG_UART_ENABLE_AUDIO_CLASS)

#include "DEBUG_UART_audio.h"
#include "DEBUG_UART_pvt.h"
#if defined(DEBUG_UART_ENABLE_MIDI_STREAMING)
    #include "DEBUG_UART_midi.h"
#endif /*  DEBUG_UART_ENABLE_MIDI_STREAMING*/


/***************************************
* Custom Declarations
***************************************/

/* `#START CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */


#if !defined(USER_SUPPLIED_AUDIO_HANDLER)


/***************************************
*    AUDIO Variables
***************************************/

#if defined(DEBUG_UART_ENABLE_AUDIO_STREAMING)
    volatile uint8 DEBUG_UART_currentSampleFrequency[DEBUG_UART_MAX_EP][DEBUG_UART_SAMPLE_FREQ_LEN];
    volatile uint8 DEBUG_UART_frequencyChanged;
    volatile uint8 DEBUG_UART_currentMute;
    volatile uint8 DEBUG_UART_currentVolume[DEBUG_UART_VOLUME_LEN];
    volatile uint8 DEBUG_UART_minimumVolume[DEBUG_UART_VOLUME_LEN] = {DEBUG_UART_VOL_MIN_LSB,
                                                                                  DEBUG_UART_VOL_MIN_MSB};
    volatile uint8 DEBUG_UART_maximumVolume[DEBUG_UART_VOLUME_LEN] = {DEBUG_UART_VOL_MAX_LSB,
                                                                                  DEBUG_UART_VOL_MAX_MSB};
    volatile uint8 DEBUG_UART_resolutionVolume[DEBUG_UART_VOLUME_LEN] = {DEBUG_UART_VOL_RES_LSB,
                                                                                     DEBUG_UART_VOL_RES_MSB};
#endif /*  DEBUG_UART_ENABLE_AUDIO_STREAMING */


/*******************************************************************************
* Function Name: DEBUG_UART_DispatchAUDIOClassRqst
********************************************************************************
*
* Summary:
*  This routine dispatches class requests
*
* Parameters:
*  None.
*
* Return:
*  requestHandled
*
* Global variables:
*   DEBUG_UART_currentSampleFrequency: Contains the current audio Sample
*       Frequency. It is set by the Host using SET_CUR request to the endpoint.
*   DEBUG_UART_frequencyChanged: This variable is used as a flag for the
*       user code, to be aware that Host has been sent request for changing
*       Sample Frequency. Sample frequency will be sent on the next OUT
*       transaction. It is contains endpoint address when set. The following
*       code is recommended for detecting new Sample Frequency in main code:
*       if((DEBUG_UART_frequencyChanged != 0) &&
*       (DEBUG_UART_transferState == DEBUG_UART_TRANS_STATE_IDLE))
*       {
*          DEBUG_UART_frequencyChanged = 0;
*       }
*       DEBUG_UART_transferState variable is checked to be sure that
*             transfer completes.
*   DEBUG_UART_currentMute: Contains mute configuration set by Host.
*   DEBUG_UART_currentVolume: Contains volume level set by Host.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 DEBUG_UART_DispatchAUDIOClassRqst(void) 
{
    uint8 requestHandled = DEBUG_UART_FALSE;
    uint8 bmRequestType  = CY_GET_REG8(DEBUG_UART_bmRequestType);

    #if defined(DEBUG_UART_ENABLE_AUDIO_STREAMING)
        uint8 epNumber;
        epNumber = CY_GET_REG8(DEBUG_UART_wIndexLo) & DEBUG_UART_DIR_UNUSED;
    #endif /*  DEBUG_UART_ENABLE_AUDIO_STREAMING */


    if ((bmRequestType & DEBUG_UART_RQST_DIR_MASK) == DEBUG_UART_RQST_DIR_D2H)
    {
        /* Control Read */
        if((bmRequestType & DEBUG_UART_RQST_RCPT_MASK) == DEBUG_UART_RQST_RCPT_EP)
        {
            /* Endpoint */
            switch (CY_GET_REG8(DEBUG_UART_bRequest))
            {
                case DEBUG_UART_GET_CUR:
                #if defined(DEBUG_UART_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_SAMPLING_FREQ_CONTROL)
                    {
                         /* point Control Selector is Sampling Frequency */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_SAMPLE_FREQ_LEN;
                        DEBUG_UART_currentTD.pData  = DEBUG_UART_currentSampleFrequency[epNumber];
                        requestHandled   = DEBUG_UART_InitControlRead();
                    }
                #endif /*  DEBUG_UART_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_READ_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else if((bmRequestType & DEBUG_UART_RQST_RCPT_MASK) == DEBUG_UART_RQST_RCPT_IFC)
        {
            /* Interface or Entity ID */
            switch (CY_GET_REG8(DEBUG_UART_bRequest))
            {
                case DEBUG_UART_GET_CUR:
                #if defined(DEBUG_UART_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_MUTE_CONTROL)
                    {
                        /* `#START MUTE_CONTROL_GET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                         /* Entity ID Control Selector is MUTE */
                        DEBUG_UART_currentTD.wCount = 1u;
                        DEBUG_UART_currentTD.pData  = &DEBUG_UART_currentMute;
                        requestHandled   = DEBUG_UART_InitControlRead();
                    }
                    else if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_VOLUME_CONTROL)
                    {
                        /* `#START VOLUME_CONTROL_GET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                        /* Entity ID Control Selector is VOLUME, */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_VOLUME_LEN;
                        DEBUG_UART_currentTD.pData  = DEBUG_UART_currentVolume;
                        requestHandled   = DEBUG_UART_InitControlRead();
                    }
                    else
                    {
                        /* `#START OTHER_GET_CUR_REQUESTS` Place other request handler here */

                        /* `#END` */
                    }
                    break;
                case DEBUG_UART_GET_MIN:    /* GET_MIN */
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_VOLUME_CONTROL)
                    {
                        /* Entity ID Control Selector is VOLUME, */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_VOLUME_LEN;
                        DEBUG_UART_currentTD.pData  = &DEBUG_UART_minimumVolume[0];
                        requestHandled   = DEBUG_UART_InitControlRead();
                    }
                    break;
                case DEBUG_UART_GET_MAX:    /* GET_MAX */
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_VOLUME_CONTROL)
                    {
                        /* Entity ID Control Selector is VOLUME, */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_VOLUME_LEN;
                        DEBUG_UART_currentTD.pData  = &DEBUG_UART_maximumVolume[0];
                        requestHandled   = DEBUG_UART_InitControlRead();
                    }
                    break;
                case DEBUG_UART_GET_RES:    /* GET_RES */
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_VOLUME_CONTROL)
                    {
                         /* Entity ID Control Selector is VOLUME, */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_VOLUME_LEN;
                        DEBUG_UART_currentTD.pData  = &DEBUG_UART_resolutionVolume[0];
                        requestHandled   = DEBUG_UART_InitControlRead();
                    }
                    break;
                /* The contents of the status message is reserved for future use.
                *  For the time being, a null packet should be returned in the data stage of the
                *  control transfer, and the received null packet should be ACKed.
                */
                case DEBUG_UART_GET_STAT:
                        DEBUG_UART_currentTD.wCount = 0u;
                        requestHandled   = DEBUG_UART_InitControlWrite();

                #endif /*  DEBUG_UART_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_WRITE_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else
        {   /* DEBUG_UART_RQST_RCPT_OTHER */
        }
    }
    else
    {
        /* Control Write */
        if((bmRequestType & DEBUG_UART_RQST_RCPT_MASK) == DEBUG_UART_RQST_RCPT_EP)
        {
            /* point */
            switch (CY_GET_REG8(DEBUG_UART_bRequest))
            {
                case DEBUG_UART_SET_CUR:
                #if defined(DEBUG_UART_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_SAMPLING_FREQ_CONTROL)
                    {
                         /* point Control Selector is Sampling Frequency */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_SAMPLE_FREQ_LEN;
                        DEBUG_UART_currentTD.pData  = DEBUG_UART_currentSampleFrequency[epNumber];
                        requestHandled   = DEBUG_UART_InitControlWrite();
                        DEBUG_UART_frequencyChanged = epNumber;
                    }
                #endif /*  DEBUG_UART_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_SAMPLING_FREQ_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else if((bmRequestType & DEBUG_UART_RQST_RCPT_MASK) == DEBUG_UART_RQST_RCPT_IFC)
        {
            /* Interface or Entity ID */
            switch (CY_GET_REG8(DEBUG_UART_bRequest))
            {
                case DEBUG_UART_SET_CUR:
                #if defined(DEBUG_UART_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_MUTE_CONTROL)
                    {
                        /* `#START MUTE_SET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                        /* Entity ID Control Selector is MUTE */
                        DEBUG_UART_currentTD.wCount = 1u;
                        DEBUG_UART_currentTD.pData  = &DEBUG_UART_currentMute;
                        requestHandled   = DEBUG_UART_InitControlWrite();
                    }
                    else if(CY_GET_REG8(DEBUG_UART_wValueHi) == DEBUG_UART_VOLUME_CONTROL)
                    {
                        /* `#START VOLUME_CONTROL_SET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                        /* Entity ID Control Selector is VOLUME */
                        DEBUG_UART_currentTD.wCount = DEBUG_UART_VOLUME_LEN;
                        DEBUG_UART_currentTD.pData  = DEBUG_UART_currentVolume;
                        requestHandled   = DEBUG_UART_InitControlWrite();
                    }
                    else
                    {
                        /* `#START OTHER_SET_CUR_REQUESTS` Place other request handler here */

                        /* `#END` */
                    }
                #endif /*  DEBUG_UART_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_CONTROL_SEL_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else
        {
            /* DEBUG_UART_RQST_RCPT_OTHER */
        }
    }

    return(requestHandled);
}

#endif /* USER_SUPPLIED_AUDIO_HANDLER */


/*******************************************************************************
* Additional user functions supporting AUDIO Requests
********************************************************************************/

/* `#START AUDIO_FUNCTIONS` Place any additional functions here */

/* `#END` */

#endif  /*  DEBUG_UART_ENABLE_AUDIO_CLASS */


/* [] END OF FILE */
