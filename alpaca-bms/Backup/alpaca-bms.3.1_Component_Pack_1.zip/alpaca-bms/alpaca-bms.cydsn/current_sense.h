#ifndef CURRENT_SENSE_H
#define CURRENT_SENSE_H

#include <project.h>
#include <stdint.h>

uint16_t get_current();
uint16_t get_soc();

#endif
